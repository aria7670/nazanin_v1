"""
Security Module
ماژول امنیتی
"""

from nazanin.security.security_manager import SecurityManager

__all__ = ['SecurityManager']
